from preprocessing import preprocess_image

image = preprocess_image('sample_image.jpg')
print('Image preprocessing completed')
